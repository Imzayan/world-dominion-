# World Dominion Online

A mobile-first browser strategy game inspired by the world-map game shown in the reference screenshot.

## Included
- Email/password registration and login
- Server-authoritative player state
- World map with country selection
- Country ownership
- Resources and army
- Real attacks with server-side validation and cooldown
- Realtime multiplayer updates through Socket.IO
- Realtime global chat
- Alliances: create, join, leave
- Online player count
- PostgreSQL persistence
- Render deployment configuration

## Run locally
1. Install Node.js 20+.
2. Create a PostgreSQL database.
3. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
4. Run:
   npm install
   npm start
5. Open http://localhost:10000

## Deploy
Push this folder to GitHub, then deploy it as a Render Web Service. Use:
- Build Command: `npm install`
- Start Command: `npm start`
- Environment variables: `DATABASE_URL`, `JWT_SECRET`

The app automatically creates its database tables at startup.

## Important
The included world map is loaded from Natural Earth through jsDelivr in the browser. For production, download and self-host the GeoJSON if you want the game to remain independent of that CDN.

This is a functional multiplayer foundation, not a finished commercial-scale MMO. For large traffic, add Redis, rate limiting, authoritative turn/event logs, anti-cheat monitoring, migrations, backups, moderation and a dedicated realtime architecture.
